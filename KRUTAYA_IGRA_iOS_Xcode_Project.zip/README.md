# KRUTAYA IGRA — iOS wrapper project

This is an Xcode project that wraps the playable Three.js horror prototype in a native WKWebView app.

## Build an unsigned IPA
Requirements: macOS, Xcode 15 or newer, iOS SDK.

1. Unzip this folder on a Mac.
2. Open Terminal and `cd` into this folder.
3. Run:
   ```bash
   ./build_unsigned_ipa.sh
   ```
4. The script creates `KRUTAYAIGRA-unsigned.ipa` in this folder.
5. Sign that IPA with your own compatible signing tool/profile.

## Important
- This package is an Xcode source project, NOT a precompiled IPA.
- It cannot be compiled on iPhone/iPad or Windows because Apple's iOS SDK and Xcode build tools are required.
- The game currently imports Three.js from jsDelivr, so an internet connection is required when the game runs.
- The app bundle identifier is `com.example.krutayaigra`. Change it in the Xcode project before signing if needed.
- This is an early prototype, not a finished commercial game.
