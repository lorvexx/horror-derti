#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
APP_NAME="KRUTAYAIGRA"
PROJECT="${APP_NAME}.xcodeproj"
DERIVED="$(pwd)/build"
xcodebuild -project "$PROJECT" -scheme "$APP_NAME" -configuration Release \
  -sdk iphoneos -derivedDataPath "$DERIVED" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  build
APP="$DERIVED/Build/Products/Release-iphoneos/${APP_NAME}.app"
if [ ! -d "$APP" ]; then
  echo "Build failed: app bundle not found"
  exit 1
fi
OUT="$(pwd)/${APP_NAME}-unsigned.ipa"
rm -rf "$DERIVED/Payload"
mkdir -p "$DERIVED/Payload"
cp -R "$APP" "$DERIVED/Payload/"
(cd "$DERIVED" && /usr/bin/zip -qr "$OUT" Payload)
echo "Created: $OUT"
